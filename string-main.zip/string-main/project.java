package Stringoperations;
import java.util.*;
public class project {
	public static void main(String args[]) {
		
//sum of series
/*int n=5;
int s=1;
for(int i=1;i<=n;i++)
{
	s*=i;//s=s*i
	System.out.println(s);
}*/
	
	//fibonacci series
		/*int n=5;
		int x=-1;
		int y=1;
		for(int i=1;i<=n;i++) {
			int z=x+y;
			x=y;
			y=z;
			System.out.println(z);
		}*/
		
//patterns
int n=3;
for(int row=1;row<=n;row++) {
	for(int col=1;col<=row;col++)
	{
		System.out.print(n);
		}
	System.out.println();
}
		
		
		
}
}
 