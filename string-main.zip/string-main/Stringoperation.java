package Stringoperations;
import java.util.*;
public class Stringoperation {
	public static void main(String[] args)
	{
		//String name = "ram";
		String name = new String("Ram");
		System.out.println(name);
	
		

	}

}