package Stringoperations;
import java.util.*;
public class Wrapperclass {
	public static void mai(String args[]) {
 /*Integer myInt=Integer.valueOf(100);
 Double myDouble=Double.valueOf(12.34);
 Character myChar=Character.valueOf('A');
 Boolean myBool=Boolean.valueOf(true);*/
		
//autoboxing
		Integer intObj=50;
		
//unboxing		
		int intValue=intObj;
		System.out.println(intValue);
}
}
