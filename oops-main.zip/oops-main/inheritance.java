package oops;
import java.util.*;
/*class Animal{
	 void sound() {
		 System.out.println("animals make sound."); //parent
	 }
 }
 /*class Dog extends Animal{
	 void bark() {                         //single inheritance           //child
		 System.out.println("Dog barks."); 
	 }
 }*/
/*class Dog extends Animal1{
	 void bark() {                                       //multi level  inheritance
		 System.out.println("Dog barks.");          //child
	 }
}*/
/*class Dog extends Animal{               //child
	 void bark() {                         
		 System.out.println("Dog barks."); 
	 }
}

class Cat extends Animal{
	void meow(){                                   //child
		System.out.println("Cat meow.");	 //hierarchical inheritance
	}
}

class Puppy extends Dog{                        //child
	void weep()
	{
		System.out.println("Puppy weeps.");
	}
}*/
class Smartphone{
 interface Camera1{
	 void capturePhoto();                       //mutliple
	 }
 interface MusicPlayer{
	 void PlayMusic();
 }
 class Smartphone implements Camera1,MusicPlayer {
	 public void capturePhoto() {
			System.out.println("photo capture using the camera."); 
	 }
	 public void playMusic() {
			System.out.println("Playing music.");
	 }
 }
 public class inheritance {
	 public static void main(String args[]) {
	/*Dog d1=new Dog();
	d1.sound();                      //single
	d1.bark();*/
		 /* Puppy p1=new Puppy();
		  p1.sound();
		  p1.bark();                  //multi level
		  p1.weep(); */
		 /*Dog d1=new Dog();
		 Cat c1=new Cat();               //hiercrchical inheritance 
		 d1.bark();
		 c1.meow();*/
		 Smartphone phone=new Smartphone();
		 .capturePhoto();
		 .
		  }
 }
