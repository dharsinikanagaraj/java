package oops;
import java.util.*;
class hotel{
	String  name="Biriyani";
	int price;
	int qty;
	void display() {
		System.out.println("name is:"+name);
		System.out.println("price is:"+price);
		System.out.println("qty is:"+qty);
	}
   
}

public class clsobj {
public static void main(String args[]) {
hotel s1=new hotel();
s1.price=210;
s1.qty=2;
s1.display();
}

}
