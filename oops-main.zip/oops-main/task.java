package oops;
import java.util.*;
class Book{
	int bookId;
	String title;
	String author;
	int price;
	Book(int bookId,String title,String author,int price){
		this.bookId=bookId;
		this.title=title;
		this.author=author;
		this.price=price;
	}
	void display() {
		System.out.println("the bookId is:"+bookId);
		System.out.println("the title is:"+title);
		System.out.println("the author is:"+author);
		System.out.println("the price is:"+price);
	}
	}
public class task {
	public static void main(String args[]) {
   Book b1=new Book(2,"The Moon","Banu",1250);
   b1.display();
}
}
