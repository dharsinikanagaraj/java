package oops;
import java.util.*;
class Student{
	public String name="ram";//public access modifier
	private int age=20;//private access modifier
	protected String grade="A";//protected access modifier
	String school="ABC school";//default access modifier

	public void displayInfo() {
		System.out.println("Name:"+name);
		System.out.println("age:"+age);
		System.out.println("grade:"+grade);
		System.out.println("school:"+school);
	}
}
public class accessmodifier {
	public static void main(String args[])
	{
		Student s1=new Student();
		s1.displayInfo();
		
    /*System.out.println("public name:"+s1.name);
	System.out.println("default school:"+s1.school);
	System.out.println("private age:"+s1.Student age);
	System.out.println("protected grade:"+student grade);*/
	}
}
