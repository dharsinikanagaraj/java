package oops;
import java.util.*;
class Data1{
	private String name;
	public String getName()//getter
{
		return name;
		}
	public void setName(String name) { //setter
		if(name!=null && !name.isEmpty()) {
			this.name=name;
		}else {
			System.out.println("invalid name!"); //validation
		}
	}
}
public class encapsulation {
public static void main(String srgs[])
{
	Data1 s1=new Data1();
	s1.setName("bavani"); //set the name using the setter
	System.out.println("Student name:"+s1.getName());//get the name using the getter
	}
}
