package oops;
import java.util.*;
/*class Car{
	String brand;
	Car(){
		brand="unknown";
	}
	void display() {
		System.out.println("the brand name is:"+brand);
	}
}*/

class Bike{
	int count;
	String Bikename;
	Bike(int count,String Bikename){//parameterized constructor
		this.count=count;
		this.Bikename=Bikename;
	}
  void display() {
	  System.out.println("the bike countis:"+count);
	  System.out.println("the Bike name is:"+Bikename);
  }
	}
public class constructors {
public static void main(String args[]) {
	/*Car c1=new Car();//default constructor
	c1.display();*/
	Bike b1=new Bike(2,"MT");
	b1.display();
}
}
