package Exception;

public class Ex2 {
static void checkAge(int age) {
			if(age<18) {
				throw new IllegalArgumentException("age must be 18 or older.");				}
		}



	public static void main(String args[]) {
	try {
		checkAge(16);
	}catch(IllegalArgumentException e) {
		System.out.println("Caugth Exception:"+e.getMessage());	
	}
	}
	
	
}


