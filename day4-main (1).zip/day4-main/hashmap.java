package Exception;
import java.util.*;
	public class hashmap {
		public static void main(String args[]) {
	HashMap<String,Integer>map=new HashMap<>();
	
	//put()
	map.put("apple",3);
	map.put("banana",2);
	map.put("orange",5);
	System.out.println("HashMap"+map);
	
	//get()
	/*System.out.println("apple count="+map.get("apple"));
	//System.out.println("mango count="+map.get("mango"));
	System.out.println("orange count="+map.get("orange"));
	
	//containskey()
	/*if(map.containsKey("Banana")) {    //checking if a key exist
		System.out.println("Banana is  the map");*/

	//remove()
	/*map.remove("orange");
	System.out.println("after removing orange:"+map);
	//size()
	System.out.println("size of Hashmap:"+map.size());*/
	
// iterating using entrySet	
/*System.out.println("Iterating using entrySet:");
for(Map.Entry<String,Integer>entry:map.entrySet()) {
	System.out.println(entry.getKey()+":"+entry.getValue());*/
	
//iterating using keySet
	/*System.out.println("Iterating using KeySet:");
	for(String key:map.keySet()) {
		System.out.println(key+":"+map.get(key));
}*/
	
	ArrayList<String>fruits=new ArrayList<>();
	fruits.add("apple");
	fruits.add("banana");
	fruits.add("cherry");
	 Iterator<String>iterator=fruits.iterator();
	 System.out.println("fruits using iterator:");
	 while(iterator.hasNext()) {
		 System.out.println(iterator.next());
	 }
	 
	}
	}
	
	
	



