package Exception;
	import java.util.*;
	public class task1{
		String name;
	   task1(String name){
			this.name=name;
			}
		void display() {
			System.out.println("name:"+name);
	}
		
			
			public static void main(String args[]) {
				task1 p1=new task1(" hello bavani");
	           
	            p1.display();
	          
	            
			}
		}




