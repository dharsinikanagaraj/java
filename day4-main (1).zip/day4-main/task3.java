package Exception;
class Candy{
	public void display( String sweet) {
		System.out.println(sweet);
	}
}
class Chocolate extends Candy{
	public void display(String Chcolatety) {
		System.out.println(Chcolatety);
	}
}
public class task3 {
public static void main(String args[]) {
	Candy c1=new Candy();
	c1.display("taste sweet");
	Chocolate c=new Chocolate();
	c.display("taste chocolate");
	
}
}
