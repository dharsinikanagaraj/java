package Exception;
	class Car{
		public void displayInfo() {
			System.out.println("this a car.");
		}
	}
	class Bmw extends Car{
		void sound() {
			System.out.println("the sound is nice.");
		}
	}
	public class task2{
public static void main(String args[]) {
	Car c1=new Car();
	Bmw b1=new Bmw();
	c1.displayInfo();
	b1.sound();
}
}
	

