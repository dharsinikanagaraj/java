package Exception;

class task {
public void display(String name) {
	System.out.println("bavani");
	
}
}
class mytask extends task{
	public void display(String name) {
		System.out.println("hello"+name);
		
	}
	
	
}
public class task4{
public static void main (String args[]) {
  mytask m1=new mytask();
  m1.display("bavani");
}
}