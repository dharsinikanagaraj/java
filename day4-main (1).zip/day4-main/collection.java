package Exception;
import java.util.*;
public class collection {
public static void main(String args[])
{ 
	//ArrayList
	/*ArrayList arrlist =new ArrayList<>();
	arrlist.add(100);
	arrlist.add(200);
	//arrlist.add("bavani");
	System.out.println(arrlist);*/
	
	//using for each for ArrayList
	
	
	/*ArrayList<Integer>arrlist=new ArrayList<>();
	for(int i=1;i<=10;i++)
	{
		arrlist.add(i);
		System.out.println(arrlist);
	}*/
	
	//using add
	
	/*ArrayList <Integer>arrlist =new ArrayList<>();
	arrlist.add(100);
	arrlist.add(200);
	arrlist.add(300);
	arrlist.add(400);
	arrlist.add(500);
	for(int i:arrlist) {
		System.out.println(i);	}*/
	
	//using get
	/*ArrayList <Integer>arrlist =new ArrayList<>();
	arrlist.add(100);
	arrlist.add(200);
	arrlist.add(300);
	arrlist.add(400);
	arrlist.add(500);
	System.out.println(arrlist.get(0));
	System.out.println(arrlist.set(0, 1000));
	System.out.println(arrlist.get(0));
	for(int i:arrlist) {
		System.out.println(i);	}*/
	
	//using remove
	/*ArrayList <Integer>arrlist =new ArrayList<>();
	arrlist.add(100);
	arrlist.add(200);
	arrlist.add(300);
	arrlist.add(400);
	arrlist.add(500);
	System.out.println(arrlist.get(0));
	System.out.println(arrlist.set(0, 1000));
	System.out.println(".........................");
	for(int i:arrlist) {
		System.out.println(i);	}*/
	
	//LinkedList
	//add
	/*LinkedList <Integer>linkedlist =new LinkedList<>();
	linkedlist.add(100);
	linkedlist.add(200);
	System.out.println(linkedlist);*/
	
	//add Fist and Last
	/*LinkedList <Integer>linkedlist =new LinkedList<>();
	//linkedlist.addLast(100);
	//linkedlist.addLast(200);
	linkedlist.addFirst(100);
	linkedlist.addFirst(200);
	System.out.println(linkedlist);*/
	
	//using get in Linkedlist
	/*LinkedList <Integer>linkedlist =new LinkedList<>();
	linkedlist.add(100);
	linkedlist.add(200);
	linkedlist.add(300);
	linkedlist.add(400);
	linkedlist.add(500);
	System.out.println(linkedlist.get(0));
	System.out.println(linkedlist.set(0, 1000));
	System.out.println(linkedlist.get(0));
	//for(int i:arrlist) {
	//System.out.println(i);	}*/
	
	//remove for linkedlist
	/*LinkedList <Integer>linkedlist =new LinkedList<>();
	linkedlist.add(100);
	linkedlist.add(200); 
	System.out.println(".........................");
	linkedlist.add(100);
	linkedlist.add(200);
	linkedlist.add(300);
	linkedlist.add(400);
	linkedlist.add(500);
	System.out.println(linkedlist);*/
	
	// queue
	/*Queue<Integer>q1=new LinkedList<>();
	q1.add(100);
	q1.add(200);
	System.out.println(q1);
	System.out.println(q1.peek());*/
	
	
//type set
	//Hashset
	/*HashSet<String>s1=new HashSet<>();
	s1.add("ram");
	s1.add("ravi");
    s1.add("ram");
    		System.out.println(s1);*/
	
	//tree set
	/*TreeSet<Integer>s1=new TreeSet<>();
	s1.add(100);
	s1.add(200);
	System.out.println(s1);*/
	

}
}
